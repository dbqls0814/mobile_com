package com.chris.cartmemo;

public interface IMainActivity
{
    void StartNewFragment(String fragmentName, int pageNumber);
}
