package com.chris.cartmemo;

import android.support.v4.app.Fragment;

import com.chris.cartmemo.Fragments.CartFragment;
import com.chris.cartmemo.Fragments.DashBoardFragment;

public class MyCartFactory {
    public static Fragment FragmentFactory(String fragmentName) {
        switch (fragmentName) {
            case "DashBoardFragment":
                return new DashBoardFragment();

            case "CartFragment":
                return  new CartFragment();

            default:
                return null;

        }
    }

    public static int GetParentLayoutIdFactory(int pageNumber) {
        switch (pageNumber) {
            default: return R.id.dashBoardRootLayout;
        }
    }
}
