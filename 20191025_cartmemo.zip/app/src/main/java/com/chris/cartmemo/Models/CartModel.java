package com.chris.cartmemo.Models;

public class CartModel {
    private String Id = "";
    private String Name = "";
    private String Pirce = "";
    private String Count = "0";
    private String Time = "";

    public String getTime() {
        return Time;
    }

    public String getCount() {
        return Count;
    }

    public String getPirce() {
        return Pirce;
    }

    public void setTime(String time) {
        Time = time;
    }

    public void setCount(String count) {
        Count = count;
    }

    public void setPirce(String pirce) {
        Pirce = pirce;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }
}
