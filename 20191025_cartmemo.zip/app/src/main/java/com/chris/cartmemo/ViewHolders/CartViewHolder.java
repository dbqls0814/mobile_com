package com.chris.cartmemo.ViewHolders;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;


import com.chris.cartmemo.R;

public class CartViewHolder extends RecyclerView.ViewHolder {

    public TextView nameTV;
    public TextView timeTV;
    public TextView countTV;
    public TextView priceTV;
    public TextView totalTV;
    public ImageButton beforeIB;
    public ImageButton afterIB;


    public CartViewHolder(@NonNull View itemView) {
        super(itemView);

        nameTV = itemView.findViewById(R.id.nameTV);
        timeTV = itemView.findViewById(R.id.timeTV);
        countTV = itemView.findViewById(R.id.countTV);
        priceTV = itemView.findViewById(R.id.priceTV);
        totalTV = itemView.findViewById(R.id.totalTV);
        beforeIB= itemView.findViewById(R.id.beforeIB);
        afterIB= itemView.findViewById(R.id.afterIB);
    }
}
