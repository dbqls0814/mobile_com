package com.chris.cartmemo;

public interface IObserver
{
    void Update();
    void Cal();
}