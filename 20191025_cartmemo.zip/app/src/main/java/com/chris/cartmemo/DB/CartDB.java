package com.chris.cartmemo.DB;

import android.provider.BaseColumns;

public class CartDB  implements BaseColumns
{
    public static final String NAME = "name";
    public static final String Price = "price";
    public static final String Count = "count";
    public static final String Company = "company";
    public static final String Time = "time";
    public static final String _TABLENAME0 = "tb_cart";
    public static final String _CREATE0 = "create table if not exists "+_TABLENAME0+"("
            +_ID+" integer primary key autoincrement, "
            +Price+" text not null , "
            +Count+" integer  not null , "
            +Company+" integer  not null , "
            +Time+" DATETIME   not null DEFAULT (datetime('now','localtime')), "
            +NAME+" text not null  );";
}
