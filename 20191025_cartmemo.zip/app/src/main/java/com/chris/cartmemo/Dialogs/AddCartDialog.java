package com.chris.cartmemo.Dialogs;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.chris.cartmemo.DefaultUtil;
import com.chris.cartmemo.MainController;
import com.chris.cartmemo.R;

public class AddCartDialog extends Dialog {
    private Button saveBtn;
    private Button cancelBtn;

    private EditText nameET;
    private TextView nameCheckTV;
    private EditText countET;
    private EditText priceET;

    private ImageButton beforeIB;
    private ImageButton afterIB;


    public boolean isAdded =false;

    public AddCartDialog(Context context) {
        super(context);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.dialog_add_cart);

        saveBtn = findViewById(R.id.saveBtn);
        cancelBtn = findViewById(R.id.cancelBtn);
        nameET = findViewById(R.id.nameET);
        nameCheckTV = findViewById(R.id.nameCheckTV);

        countET = findViewById(R.id.countET);
        priceET = findViewById(R.id.priceET);
        beforeIB = findViewById(R.id.beforeIB);
        beforeIB.setOnClickListener(v->{

            try {
                int value =  Integer.parseInt(countET.getText().toString()) -1;

                if(value < 0)
                {
                    value = 0;
                }

                countET.setText(String.valueOf(value));
            }
            catch (Exception e)
            {
                countET.setText("0");
            }
        });

        afterIB = findViewById(R.id.afterIB);
        afterIB.setOnClickListener(v->{
            try {
                int value =  Integer.parseInt(countET.getText().toString()) +1;

                if(value < 0)
                {
                    value = 0;
                }

                countET.setText(String.valueOf(value));
            }
            catch (Exception e)
            {
                countET.setText("0");
            }
        });

        //다이얼로그 크기 조절.
        DefaultUtil.getDialogSize(getContext(), this);

        nameET.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!nameET.getText().toString().trim().isEmpty()) {
                    nameCheckTV.setVisibility(View.GONE);
                } else {
                    nameCheckTV.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable arg0) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
        });



        setCancelable(false);
        cancelBtn.setOnClickListener(v -> dismiss());
        saveBtn.setOnClickListener(v -> UpdateInfo());
    }


    private void UpdateInfo() {
        //name blank check
        if (nameET.getText().toString().trim().isEmpty()) {

            nameET.setText(getContext().getString(R.string.input_item));
        }

        if (priceET.getText().toString().trim().isEmpty()) {

            priceET.setText("0");
        }


        if (countET.getText().toString().trim().isEmpty()) {

            countET.setText("0");
        }

        MainController.getInstance().dbHelper.insertCart(nameET.getText().toString(), priceET.getText().toString(), countET.getText().toString(), MainController.getInstance().SelectedCompany.getId());

        isAdded =true;

        dismiss();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        dismiss();
    }

}
