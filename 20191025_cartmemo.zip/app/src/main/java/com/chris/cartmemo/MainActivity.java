package com.chris.cartmemo;


import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.chris.cartmemo.Adapters.PageAdapter;
import com.chris.cartmemo.DB.DBHelper;
import com.chris.cartmemo.Dialogs.AddCartDialog;
import com.chris.cartmemo.Dialogs.AddCompanyDialog;
import com.chris.cartmemo.Fragments.CartFragment;
import com.chris.cartmemo.Fragments.DashBoardFragment;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import static com.chris.cartmemo.MyCartFactory.FragmentFactory;
import static com.chris.cartmemo.MyCartFactory.GetParentLayoutIdFactory;

public class MainActivity extends AppCompatActivity  implements  IMainActivity{

    String currentPage = DashBoardFragment.class.getSimpleName();;
    TabLayout tabLayout;
    ViewPager viewPager;
    PageAdapter pageAdapter;
    TextView titleTV;
    public ImageButton backIB;
    private ImageButton addIB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MainController.getInstance().dbHelper = new DBHelper(this);
        MainController.getInstance().dbHelper.open();
        MainController.getInstance().dbHelper.create();
        mainActivity = this;

        titleTV = findViewById(R.id.titleTV);
        addIB = findViewById(R.id.addIB);
        addIB.setOnClickListener(v -> {
            switch (lastViewName) {

                case "DashBoardFragment":
                    DialogCompanyAdd();
                    break;

                case "CartFragment":
                    DialogCartAdd();
                    break;
            }
        });


        backIB = findViewById(R.id.backIB);
        backIB.setOnClickListener(new View.OnClickListener() {

            int index = 0;

            @Override
            public void onClick(View v) {
                Fragment fragment = null;

                switch (currentPage) {
                    case "DashBoardFragment":
                        index = 0;
                        fragment = pageAdapter.getItem(0);

                        currentPage = fragment.getClass().getSimpleName();
                        ((DashBoardFragment) pageAdapter.mList.get(0)).setVisible(true);

                        break;

                    case "SettingFragment":
                        index = 1;
                        fragment = pageAdapter.getItem(1);

                        break;
                }

                if (fragment != null) {
                    int count = fragment.getChildFragmentManager().getBackStackEntryCount();


                    if (count > 0) {

                        fragment.getChildFragmentManager().popBackStackImmediate();

                        count = fragment.getChildFragmentManager().getBackStackEntryCount();

                        if (count > 0) {
                            SetCurrentView(fragment.getChildFragmentManager().getBackStackEntryAt(count - 1).getName());
                        } else {
                            SetCurrentView(currentPage);
                        }
                    }

                }
            }
        });


        viewPager = findViewById(R.id.viewPager);
        viewPager.setOffscreenPageLimit(1);

        pageAdapter = new PageAdapter(getSupportFragmentManager(), 1);


        for (int i = 0; i < 1; i++) {

            Fragment fragment = null;

            switch (i) {
                case 0:

                    fragment = new DashBoardFragment();

                    break;

                default:
                    fragment = null;
                    break;
            }

            if (fragment != null) {
                pageAdapter.mList.add(fragment);
            }
        }

        viewPager.setAdapter(pageAdapter);
    }


    public void StartNewFragment(String fragmentName, int pageNumber) {

        Fragment fragment = FragmentFactory(fragmentName);
        SetCurrentView(fragmentName);
        FragmentTransaction transaction = pageAdapter.mList.get(pageNumber).getChildFragmentManager().beginTransaction();
        transaction.replace(GetParentLayoutIdFactory(pageNumber), fragment, fragmentName);
        transaction.addToBackStack(fragmentName);
        transaction.commitAllowingStateLoss();
    }


    private String lastViewName = "DashBoardFragment";
    public void SetCurrentView(String viewName) {
        lastViewName = viewName;

        switch (viewName) {
            case "DashBoardFragment":
                titleTV.setVisibility(View.VISIBLE);
                backIB.setVisibility(View.GONE);
                addIB.setVisibility(View.VISIBLE);
                titleTV.setText(getText(R.string.store_list));

                break;

            case "CartFragment":
                titleTV.setVisibility(View.VISIBLE);
                backIB.setVisibility(View.VISIBLE);
                addIB.setVisibility(View.VISIBLE);
                titleTV.setText(getText(R.string.cart_list));
                break;
        }

    }



    private AddCompanyDialog addCompanyDialog;
    private void DialogCompanyAdd() {
        if (addCompanyDialog != null && addCompanyDialog.isShowing()) {
            return;
        }
        addCompanyDialog = new AddCompanyDialog(this);
        addCompanyDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        addCompanyDialog.setOnDismissListener(dialog ->
        {
            if(addCompanyDialog.addCompany && MainController.getInstance().IdashBoardFragment !=null)
            {
                MainController.getInstance().IdashBoardFragment.Update();
            }
            addCompanyDialog = null;
        });
        addCompanyDialog.show();
    }


    private AddCartDialog addCartDialog;
    private void DialogCartAdd() {
        if (addCartDialog != null && addCartDialog.isShowing()) {
            return;
        }
        addCartDialog = new AddCartDialog(this);
        addCartDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        addCartDialog.setOnDismissListener(dialog ->
        {
            if(addCartDialog.isAdded && MainController.getInstance().IcartFragment !=null)
            {
                MainController.getInstance().IcartFragment.Update();
            }
            addCartDialog = null;
        });
        addCartDialog.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if(MainController.getInstance().dbHelper != null) {
            MainController.getInstance().dbHelper.close();
        }
    }

    public static MainActivity mainActivity;


    @Override
    public void onBackPressed() {

        finishFragment();
    }


    public void finishFragment() {
        Fragment fragment = null;

        switch (currentPage) {
            case "DashBoardFragment":
                fragment = pageAdapter.getItem(0);

                break;

            case "SettingFragment":
                fragment = pageAdapter.getItem(1);

                break;
        }

        if (fragment != null) {

            int count = fragment.getChildFragmentManager().getBackStackEntryCount();


            if (count > 0) {

                fragment.getChildFragmentManager().popBackStackImmediate();

                count = fragment.getChildFragmentManager().getBackStackEntryCount();

                if (count > 0) {
                    SetCurrentView(fragment.getChildFragmentManager().getBackStackEntryAt(count - 1).getName());
                } else {
                    SetCurrentView(currentPage);
                }
            }
            else
            {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                startActivity(intent);
            }


        } else {
            Intent intent = new Intent();
            intent.setAction(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            startActivity(intent);
        }
    }

}
