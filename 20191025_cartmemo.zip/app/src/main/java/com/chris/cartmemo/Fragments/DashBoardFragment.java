package com.chris.cartmemo.Fragments;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.NestedScrollView;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.chris.cartmemo.Adapters.DashBoardAdapter;
import com.chris.cartmemo.IObserver;
import com.chris.cartmemo.MainController;
import com.chris.cartmemo.Models.CompanyModel;
import com.chris.cartmemo.R;

public class DashBoardFragment extends Fragment implements IObserver {

    public DashBoardFragment() {
        // Required empty public constructor
    }

    private SwipeRefreshLayout swipeRefreshLayout;

    private RecyclerView recyclerView;
    private TextView dataEmptyTV;


    private DashBoardAdapter adapter;

    private NestedScrollView scrollView;

    public void setVisible(boolean value)
    {
        if(value)
        {
            scrollView.setVisibility(View.VISIBLE);
        }
        else
        {
            scrollView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dash_board, container, false);


        MainController.getInstance().IdashBoardFragment = this;
        swipeRefreshLayout = view.findViewById(R.id.swipeRefresh);
        scrollView = view.findViewById(R.id.nestedScrollView);
        recyclerView = view.findViewById(R.id.recyclerView);
        dataEmptyTV = view.findViewById(R.id.dataEmptyTV);

        adapter = new DashBoardAdapter(getContext());
        recyclerView.setAdapter(adapter);


        swipeRefreshLayout.setOnRefreshListener(this::getData);

        swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);

        swipeRefreshLayout.setDistanceToTriggerSync(500);

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        getData();
    }

    public void getData() {

        swipeRefreshLayout.setRefreshing(true);
        adapter.list.clear();


        if (MainController.getInstance().dbHelper != null) {
            Cursor iCursor = MainController.getInstance().dbHelper.select("select * from tb_company");
            while (iCursor.moveToNext()) {
                String id = iCursor.getString(iCursor.getColumnIndex("_id"));
                String name = iCursor.getString(iCursor.getColumnIndex("name"));

                CompanyModel companyModel = new CompanyModel();
                companyModel.setId(id);
                companyModel.setName(name);

                adapter.list.add(companyModel);
            }

        }


        if(adapter.list.size()>0)
        {
            recyclerView.setVisibility(View.VISIBLE);
            dataEmptyTV.setVisibility(View.GONE);
        }
        else
        {
            recyclerView.setVisibility(View.GONE);
            dataEmptyTV.setVisibility(View.VISIBLE);
        }

        adapter.notifyDataSetChanged();
        swipeRefreshLayout.setRefreshing(false);
    }

    public void Update()
    {
        getData();
    }

    public void Cal()
    {

    }
}
