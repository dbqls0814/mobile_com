package com.chris.cartmemo.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper {

    private static final String DATABASE_NAME = "InnerDatabase(SQLite).db";
    private static final int DATABASE_VERSION = 1;
    public static SQLiteDatabase mDB;
    private DatabaseHelper mDBHelper;
    private Context mCtx;

    private class DatabaseHelper extends SQLiteOpenHelper {

        public DatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db){
            db.execSQL(CompanyDB._CREATE0);
            db.execSQL(CartDB._CREATE0);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
            db.execSQL("DROP TABLE IF EXISTS "+CompanyDB._TABLENAME0);
            db.execSQL("DROP TABLE IF EXISTS "+CartDB._TABLENAME0);
            onCreate(db);
        }
    }

    public DBHelper(Context context){
        this.mCtx = context;
    }

    public DBHelper open() throws SQLException {
        mDBHelper = new DatabaseHelper(mCtx, DATABASE_NAME, null, DATABASE_VERSION);
        mDB = mDBHelper.getWritableDatabase();
        return this;
    }

    public void create(){
        mDBHelper.onCreate(mDB);
    }

    public void close(){
        mDB.close();
    }

    public Cursor select(String query){
        Cursor c = mDB.rawQuery( query, null);
        return c;
    }


    public long insertCompany(String name){
        ContentValues values = new ContentValues();
        values.put(CompanyDB.NAME, name);
        return mDB.insert(CompanyDB._TABLENAME0, null, values);
    }

    public boolean updateCompany(String id, String name){
        ContentValues values = new ContentValues();
        values.put(CompanyDB.NAME, name);
        return mDB.update(CompanyDB._TABLENAME0, values, "_id=" + id, null) > 0;
    }

    public long insertCart(String name, String price, String count, String company){
        ContentValues values = new ContentValues();
        values.put(CartDB.NAME, name);
        values.put(CartDB.Price, price);
        values.put(CartDB.Count, count);
        values.put(CartDB.Company, company);
        return mDB.insert(CartDB._TABLENAME0, null, values);
    }

    public boolean updateCartCount(String id, String count){
        ContentValues values = new ContentValues();
        values.put(CartDB.Count, count);
        return mDB.update(CartDB._TABLENAME0, values, "_id=" + id, null) > 0;
    }

    public boolean updateCart(String id, String name, String price, String count, String time, String company){
        ContentValues values = new ContentValues();
        values.put(CartDB.NAME, name);
        values.put(CartDB.Price, price);
        values.put(CartDB.Count, count);
        values.put(CartDB.Time, time);
        values.put(CartDB.Company, company);
        return mDB.update(CartDB._TABLENAME0, values, "_id=" + id, null) > 0;
    }

    public boolean deleteColumn(String tableName, String id){
        return mDB.delete(tableName, "_id="+id, null) > 0;
    }
}

