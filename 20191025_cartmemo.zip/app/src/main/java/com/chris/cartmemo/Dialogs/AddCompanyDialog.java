package com.chris.cartmemo.Dialogs;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.chris.cartmemo.DefaultUtil;
import com.chris.cartmemo.MainController;
import com.chris.cartmemo.R;

public class AddCompanyDialog extends Dialog {
    private Button saveBtn;
    private Button cancelBtn;
    private EditText nameET;
    private TextView nameCheckTV;
    public boolean addCompany =false;

    public AddCompanyDialog(Context context) {
        super(context);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.dialog_add_company);

        saveBtn = findViewById(R.id.saveBtn);
        cancelBtn = findViewById(R.id.cancelBtn);
        nameET = findViewById(R.id.nameET);
        nameCheckTV = findViewById(R.id.nameCheckTV);

        //다이얼로그 크기 조절.
        DefaultUtil.getDialogSize(getContext(), this);

        nameET.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!nameET.getText().toString().trim().isEmpty()) {
                    nameCheckTV.setVisibility(View.GONE);
                } else {
                    nameCheckTV.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable arg0) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
        });

        setCancelable(false);
        cancelBtn.setOnClickListener(v -> dismiss());
        saveBtn.setOnClickListener(v -> UpdateInfo());
    }


    private void UpdateInfo() {

        if (nameET.getText().toString().trim().isEmpty()) {
            nameCheckTV.setVisibility(View.VISIBLE);
            nameET.requestFocus();
            return;
        }

        addCompany =true;
        MainController.getInstance().dbHelper.insertCompany(nameET.getText().toString());
        dismiss();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        dismiss();
    }
}
