package com.chris.cartmemo.ViewHolders;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;



import com.chris.cartmemo.R;

public class DashboardViewHolder extends RecyclerView.ViewHolder {
    public TextView siteTV;
    public ImageView ownerIV;

    public DashboardViewHolder(@NonNull View itemView) {
        super(itemView);
        siteTV = itemView.findViewById(R.id.siteTV);
        ownerIV = itemView.findViewById(R.id.settingIV);
    }
}