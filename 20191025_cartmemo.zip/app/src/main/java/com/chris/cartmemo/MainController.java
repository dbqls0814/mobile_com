package com.chris.cartmemo;

import com.chris.cartmemo.DB.DBHelper;
import com.chris.cartmemo.Models.CartModel;
import com.chris.cartmemo.Models.CompanyModel;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class MainController {
    private static final MainController instance = new MainController();

    protected MainController() {
    }

    public static MainController getInstance() {
        return instance;
    }

    public boolean isCart = false;
    public IObserver IdashBoardFragment;
    public IObserver IcartFragment;
    public CompanyModel SelectedCompany = null;
    public CartModel SelectedCart = null;

    public DBHelper dbHelper;
    public DateFormat defaultDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    public DateFormat defaultTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public DateFormat defaultTimeForma2 = new SimpleDateFormat("HH:mm:ss");

}
