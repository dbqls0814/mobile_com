package com.chris.cartmemo.Fragments;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.helper.Layer;
import android.support.v4.app.Fragment;
import android.support.v4.widget.NestedScrollView;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;


import com.chris.cartmemo.Adapters.CartAdapter;
import com.chris.cartmemo.DefaultUtil;
import com.chris.cartmemo.IObserver;
import com.chris.cartmemo.MainController;
import com.chris.cartmemo.Models.CartModel;
import com.chris.cartmemo.R;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

public class CartFragment extends Fragment implements IObserver {

    public CartFragment() {
        // Required empty public constructor
    }


    private String strStartDate = "";
    private String strEndDate = "";
    private Date startDate = new Date();
    private Date endDate = new Date();

    private SwipeRefreshLayout swipeRefreshLayout;
    private ImageButton beforeIB;
    private ImageButton afterIB;
    private TextView dateTV;
    private Layer dateSelectLayer;

    private RecyclerView recyclerView;
    private TextView dataEmptyTV;
    private TextView totalTV;


    private CartAdapter adapter;

    private DatePickerDialog datePickDialog;

    private boolean isBusy;
    private NestedScrollView scrollView;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_cart, container, false);


        MainController.getInstance().isCart = true;
        MainController.getInstance().IcartFragment = this;
        swipeRefreshLayout = view.findViewById(R.id.swipeRefresh);
        scrollView = view.findViewById(R.id.nestedScrollView);
        beforeIB = view.findViewById(R.id.beforeIB);
        afterIB = view.findViewById(R.id.afterIB);
        dateTV = view.findViewById(R.id.dateTV);
        dateSelectLayer = view.findViewById(R.id.dateSelectLayer);
        recyclerView = view.findViewById(R.id.recyclerView);
        dataEmptyTV = view.findViewById(R.id.dataEmptyTV);


        totalTV = view.findViewById(R.id.totalTV);
        adapter = new CartAdapter(getContext());
        recyclerView.setAdapter(adapter);


        swipeRefreshLayout.setOnRefreshListener(this::getData);

        swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);

        swipeRefreshLayout.setDistanceToTriggerSync(500);


        dateSelectLayer.setOnClickListener(v -> {
            if (isBusy) {
                return;
            }
            DialogDateSelect();
        });

        beforeIB.setOnClickListener(v -> {
            if (isBusy) {
                return;
            }
            setDate(-1);
            getData();
        });
        afterIB.setOnClickListener(v -> {
            if (isBusy) {
                return;
            }
            setDate(1);
            getData();
        });

        try {
            dateTV.setText(MainController.getInstance().defaultDateFormat.format(MainController.getInstance().defaultDateFormat.parse(strStartDate)));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        strStartDate = strEndDate = MainController.getInstance().defaultDateFormat.format(Calendar.getInstance().getTime());

        try {
            dateTV.setText(MainController.getInstance().defaultDateFormat.format(MainController.getInstance().defaultDateFormat.parse(strStartDate)));
        } catch (ParseException e) {
            e.printStackTrace();
        }


        return view;
    }

    @Override
    public void onResume() {
        super.onResume();

        getData();
    }

    public void getData() {

        swipeRefreshLayout.setRefreshing(true);
        adapter.list.clear();

        try {
            dateTV.setText(MainController.getInstance().defaultDateFormat.format(MainController.getInstance().defaultDateFormat.parse(strStartDate)));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        double total = 0;

        if (MainController.getInstance().dbHelper != null) {

            String sql = "select * from tb_cart ";
            sql += " where company = " + MainController.getInstance().SelectedCompany.getId() + " and time >=  '" + strStartDate + " 00:00:00' and time <= '" + strEndDate + " 23:59:59'  order by _id desc; ";


            Cursor iCursor = MainController.getInstance().dbHelper.select(sql);
            while (iCursor.moveToNext()) {
                String id = iCursor.getString(iCursor.getColumnIndex("_id"));
                String name = iCursor.getString(iCursor.getColumnIndex("name"));
                String price = iCursor.getString(iCursor.getColumnIndex("price"));
                String count = iCursor.getString(iCursor.getColumnIndex("count"));
                String time = iCursor.getString(iCursor.getColumnIndex("time"));

                CartModel cartModel = new CartModel();
                cartModel.setId(id);
                cartModel.setName(name);
                cartModel.setPirce(price);
                cartModel.setCount(count);
                cartModel.setTime(time);


                int count2 = Integer.parseInt(cartModel.getCount());
                double price2 = Double.parseDouble(cartModel.getPirce());

                total = total + (price2 * count2);
                adapter.list.add(cartModel);
            }

        }

        totalTV.setText(DefaultUtil.getLocaleMoneyUnit(getContext(), String.valueOf(total)));
        adapter.notifyDataSetChanged();

        if(adapter.list.size()>0)
        {
            recyclerView.setVisibility(View.VISIBLE);
            dataEmptyTV.setVisibility(View.GONE);
        }
        else
        {
            recyclerView.setVisibility(View.GONE);
            dataEmptyTV.setVisibility(View.VISIBLE);
        }

        swipeRefreshLayout.setRefreshing(false);
    }

    public void Update()
    {
        getData();
    }

    private void setDate(int addAmount) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);
        calendar.add(Calendar.DATE, addAmount);
        startDate = endDate = calendar.getTime();
        strStartDate = MainController.getInstance().defaultDateFormat.format(startDate);
        strEndDate = MainController.getInstance().defaultDateFormat.format(endDate);
    }

    private void DialogDateSelect() {
        if (datePickDialog != null && datePickDialog.isShowing()) {
            return;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);

        datePickDialog = new DatePickerDialog(getContext(), (view, year, month, dayOfMonth) -> { },
                calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));

        datePickDialog.setButton(DialogInterface.BUTTON_NEUTRAL, getString(R.string.today), (Message) null);
        datePickDialog.setButton(DatePickerDialog.BUTTON_POSITIVE, null, (DialogInterface.OnClickListener) null);
        datePickDialog.show();

        datePickDialog.getDatePicker().init(calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH),
                (view, year, monthOfYear, dayOfMonth) -> {
                    calendar.set(year, monthOfYear, dayOfMonth);
                    strStartDate = MainController.getInstance().defaultDateFormat.format(calendar.getTime());
                    strEndDate = MainController.getInstance().defaultDateFormat.format(calendar.getTime());
                    try {
                        startDate = MainController.getInstance().defaultDateFormat.parse(strStartDate);

                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    getData();
                    datePickDialog.dismiss();
                });

        Button todayBtn = datePickDialog.getButton(DialogInterface.BUTTON_NEUTRAL);
        todayBtn.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            datePickDialog.updateDate(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
        });
    }

    public void Cal()
    {
        double total = 0;

        for(int i= 0; i <adapter.list.size(); i++)
        {
            int count = Integer.parseInt(adapter.list.get(i).getCount());
            double price = Double.parseDouble(adapter.list.get(i).getPirce());

            total = total + (price * count);
        }

        totalTV.setText(DefaultUtil.getLocaleMoneyUnit(getContext(), String.valueOf(total)));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        MainController.getInstance().IcartFragment = null;
        MainController.getInstance().isCart = false;
    }
}

