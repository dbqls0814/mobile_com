package com.chris.cartmemo.Adapters;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;

import com.chris.cartmemo.DefaultUtil;
import com.chris.cartmemo.Dialogs.EditCartDialog;
import com.chris.cartmemo.MainController;
import com.chris.cartmemo.Models.CartModel;
import com.chris.cartmemo.R;
import com.chris.cartmemo.ViewHolders.CartViewHolder;

import java.util.ArrayList;
import java.util.List;

public class CartAdapter extends RecyclerView.Adapter {
        public List<CartModel> list = new ArrayList<>();
        public boolean useAnimation = true;

        private Context context;


        public CartAdapter(Context context) {
            this.context = context;


        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
            View itemView = LayoutInflater.
                    from(viewGroup.getContext()).
                    inflate(R.layout.viewholder_cart, viewGroup, false);
            return new CartViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
            CartModel item = list.get(position);
            CartViewHolder viewHolder = (CartViewHolder) holder;

            if (item.getName() != null && !item.getName().isEmpty()) {
                viewHolder.nameTV.setText(item.getName());
            } else {
                viewHolder.nameTV.setText(context.getString(R.string.input_item));
            }

            viewHolder.countTV.setText(item.getCount());
            viewHolder.priceTV.setText(DefaultUtil.getLocaleMoneyUnit(context, item.getPirce()));

            try {
                int count = Integer.parseInt(item.getCount());
                double price = Double.parseDouble(item.getPirce());

                double total = price * count;
                viewHolder.totalTV.setText(DefaultUtil.getLocaleMoneyUnit(context, String.valueOf(total)));
            }
            catch (Exception e)
            {
                viewHolder.totalTV.setText(DefaultUtil.getLocaleMoneyUnit(context,"0"));
            }

            try {

                viewHolder.timeTV.setText(MainController.getInstance().defaultTimeForma2.format(MainController.getInstance().defaultTimeFormat.parse(item.getTime())));
            }
            catch (Exception e)
            {
                viewHolder.timeTV.setText("-");
            }

            viewHolder.itemView.setOnClickListener(v -> {

                //수정 Dialog
                MainController.getInstance().SelectedCart = item;
                DialogCompanyEdit();
            });


            viewHolder.afterIB.setOnClickListener(v-> {

                        try {
                            int count = Integer.parseInt(item.getCount()) + 1;
                            double price = Double.parseDouble(item.getPirce());


                            viewHolder.countTV.setText(String.valueOf(count));
                            item.setCount(String.valueOf(count));
                            MainController.getInstance().dbHelper.updateCartCount(item.getId(), item.getCount());
                            double total = price * count;
                            viewHolder.totalTV.setText(DefaultUtil.getLocaleMoneyUnit(context, String.valueOf(total)));

                            MainController.getInstance().IcartFragment.Cal();

                        } catch (Exception e) {
                            //viewHolder.totalTV.setText(DefaultUtil.getLocaleMoneyUnit(context,"0"));
                        }
                    }

            );

            viewHolder.beforeIB.setOnClickListener(v->{

                try {
                    int count =  Integer.parseInt(item.getCount()) - 1;

                    if(count < 1)
                    {
                        count = 1;
                    }

                    double price = Double.parseDouble(item.getPirce());

                    viewHolder.countTV.setText(String.valueOf(count));
                    item.setCount(String.valueOf(count));
                    MainController.getInstance().dbHelper.updateCartCount(item.getId(), item.getCount());
                    double total = price * count;
                    viewHolder.totalTV.setText(DefaultUtil.getLocaleMoneyUnit(context, String.valueOf(total)));

                    MainController.getInstance().IcartFragment.Cal();
                }
                catch (Exception e)
                {
                    //viewHolder.totalTV.setText(DefaultUtil.getLocaleMoneyUnit(context,"0"));
                }

            });

            if (useAnimation) {
                setAnimation(holder.itemView);
            }
        }

    @Override
    public int getItemCount() {
        return list.size();
    }

    private void setAnimation(View viewToAnimate) {
        ScaleAnimation anim = new ScaleAnimation(0.0f, 1.0f, 0.0f, 1.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        anim.setDuration(500);//to make duration random number between [0,501)
        viewToAnimate.startAnimation(anim);
    }


    private EditCartDialog editCartDialog;
    private void DialogCompanyEdit() {
        if (editCartDialog != null && editCartDialog.isShowing()) {
            return;
        }
        editCartDialog = new EditCartDialog(context);
        editCartDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        editCartDialog.setOnDismissListener(dialog ->
        {
            if(editCartDialog.isAdded && MainController.getInstance().IcartFragment !=null)
            {
                MainController.getInstance().IcartFragment.Update();
            }
            editCartDialog = null;
        });
        editCartDialog.show();
    }
}
