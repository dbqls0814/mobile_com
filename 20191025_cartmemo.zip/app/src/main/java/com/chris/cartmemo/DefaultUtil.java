package com.chris.cartmemo;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Point;
import android.util.Size;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

import static android.content.Context.WINDOW_SERVICE;

public class DefaultUtil {

    public static int dpToPx(int dp, Context context) {
        float density = context.getResources()
                .getDisplayMetrics()
                .density;
        return Math.round((float) dp * density);
    }

    public static Point getDisplaySize(Context c) {
        WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        final Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);

        return size;
    }

    public static void getDialogSize(Context context, Dialog dialog) {
        WindowManager wm = (WindowManager) context.getSystemService(WINDOW_SERVICE);
        final Display display = wm.getDefaultDisplay();

        Point size = new Point();
        display.getSize(size);
        int width = size.x - dpToPx(30, context);
//        int width = size.x - 100;
        int height = size.y - 80;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = width;
        dialog.getWindow().setAttributes(lp);
    }

    public static Size getViewSize(View view) {
        view.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);

        int width = view.getMeasuredWidth();
        int height = view.getMeasuredHeight();

        Size size = new Size(width, height);

        return size;
    }


    public static String getLocaleMoneyUnit(Context context, String money) {
        String localeMoneyWithUnit = "";

        switch (context.getResources().getConfiguration().locale.getLanguage()) {
            default:
                if(money.equals("-")) {
                    localeMoneyWithUnit = money;
                }else {
                    localeMoneyWithUnit = "\u20A9" + makeMoneyType(Double.parseDouble(money), 0);
                }
                break;
            case "en":
                if(money.equals("-")){
                    localeMoneyWithUnit=money;
                }else {
                    if (money.equals("0")) {
                        localeMoneyWithUnit = "$ " + makeMoneyType(Double.parseDouble(money), 0);
                    } else {
                        localeMoneyWithUnit = "$ " + makeMoneyType(Double.parseDouble(money), 3);
                    }
                }
                break;
        }
        return localeMoneyWithUnit;
    }

    public static String makeMoneyType(double dblMoneyString, int point) {
        String moneyString = Double.toString(dblMoneyString);
        String point_add_text = "";
        String format = "";
        if (point > 1) {
            int count = point - 1;
            for (int i = 0; i < count; i++) {
                point_add_text += "0";
            }
            format = "#,##0." + point_add_text;
        } else {
            format = "#,##0";
        }

//		String format = "#,##0.00";
        DecimalFormat df = new DecimalFormat(format);
        DecimalFormatSymbols dfs = new DecimalFormatSymbols();

        dfs.setGroupingSeparator(',');// 구분자를 ,로
        df.setGroupingSize(3);//3자리 단위마다 구분자처리 한다.
        df.setDecimalFormatSymbols(dfs);

        return (df.format(Double.parseDouble(moneyString)));
    }

}

