package com.chris.cartmemo.Dialogs;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.chris.cartmemo.DB.CartDB;
import com.chris.cartmemo.DefaultUtil;
import com.chris.cartmemo.MainActivity;
import com.chris.cartmemo.MainController;
import com.chris.cartmemo.R;

public class EditCartDialog extends Dialog {
    private Button saveBtn;
    private Button cancelBtn;
    private EditText nameET;
    private TextView nameCheckTV;
    private EditText countET;
    private EditText priceET;
    private Button deleteBtn;
    private ImageButton beforeIB;
    private ImageButton afterIB;


    public boolean isAdded =false;

    public EditCartDialog(Context context) {
        super(context);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.dialog_add_cart);

        saveBtn = findViewById(R.id.saveBtn);
        cancelBtn = findViewById(R.id.cancelBtn);
        nameET = findViewById(R.id.nameET);

        nameET.setText(MainController.getInstance().SelectedCart.getName());

        nameCheckTV = findViewById(R.id.nameCheckTV);

        deleteBtn = findViewById(R.id.deleteBtn);
        deleteBtn.setVisibility(View.VISIBLE);

        deleteBtn.setOnClickListener(v->{

            DialogDeletePayConfirm();

        });

        countET = findViewById(R.id.countET);
        countET.setText(MainController.getInstance().SelectedCart.getCount());

        priceET = findViewById(R.id.priceET);
        priceET.setText(MainController.getInstance().SelectedCart.getPirce());

        beforeIB = findViewById(R.id.beforeIB);
        beforeIB.setOnClickListener(v->{

            try {
                int value =  Integer.parseInt(countET.getText().toString()) -1;

                if(value < 0)
                {
                    value = 0;
                }

                countET.setText(String.valueOf(value));
            }
            catch (Exception e)
            {
                countET.setText("0");
            }
        });

        afterIB = findViewById(R.id.afterIB);
        afterIB.setOnClickListener(v->{
            try {
                int value =  Integer.parseInt(countET.getText().toString()) +1;

                if(value < 0)
                {
                    value = 0;
                }

                countET.setText(String.valueOf(value));
            }
            catch (Exception e)
            {
                countET.setText("0");
            }
        });

        //다이얼로그 크기 조절.
        DefaultUtil.getDialogSize(getContext(), this);

        nameET.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!nameET.getText().toString().trim().isEmpty()) {
                    nameCheckTV.setVisibility(View.GONE);
                } else {
                    nameCheckTV.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable arg0) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
        });

        setCancelable(false);
        cancelBtn.setOnClickListener(v -> dismiss());
        saveBtn.setOnClickListener(v -> UpdateInfo());
    }

    private void UpdateInfo() {
        //name blank check
        if (nameET.getText().toString().trim().isEmpty()) {

            nameET.setText(getContext().getString(R.string.input_item));
        }

        if (priceET.getText().toString().trim().isEmpty()) {

            priceET.setText("0");
        }


        if (countET.getText().toString().trim().isEmpty()) {

            countET.setText("0");
        }

        MainController.getInstance().dbHelper.updateCart(MainController.getInstance().SelectedCart.getId(), nameET.getText().toString(), priceET.getText().toString(), countET.getText().toString(), MainController.getInstance().SelectedCart.getTime(), MainController.getInstance().SelectedCompany.getId());

        isAdded =true;

        dismiss();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        dismiss();
    }

    private YesNoBottomDialog editConfirmDialog;

    private void DialogDeletePayConfirm() {
        if (editConfirmDialog != null && editConfirmDialog.isVisible()) {
            return;
        }
        editConfirmDialog = new YesNoBottomDialog();

        editConfirmDialog.show(MainActivity.mainActivity.getSupportFragmentManager(), "delete");
        MainActivity.mainActivity.getSupportFragmentManager().executePendingTransactions();
        editConfirmDialog.getDialog().setOnDismissListener(dialog -> {
            if (editConfirmDialog.isConfirm) {

                //삭제
                if(MainController.getInstance().dbHelper != null)
                {
                    MainController.getInstance().dbHelper.deleteColumn(CartDB._TABLENAME0, MainController.getInstance().SelectedCart.getId());
                    MainController.getInstance().IcartFragment.Update();
                    dismiss();
                }
            }
            editConfirmDialog.dismiss();
        });
    }
}
