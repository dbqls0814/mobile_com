package com.chris.cartmemo.Dialogs;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.BottomSheetDialog;
import android.support.design.widget.BottomSheetDialogFragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.chris.cartmemo.DefaultUtil;
import com.chris.cartmemo.R;

public class YesNoBottomDialog extends BottomSheetDialogFragment {
    public Button cancelBtn;
    public Button confirmBtn;
    private TextView contentTV;
    private TextView titleTV;
    private LinearLayout bottomSheetLayout;
    public boolean isConfirm = false;

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        BottomSheetDialog dialog = (BottomSheetDialog) super.onCreateDialog(savedInstanceState);

        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                BottomSheetDialog d = (BottomSheetDialog) dialog;

                FrameLayout bottomSheet = (FrameLayout) d.findViewById(android.support.design.R.id.design_bottom_sheet);
                BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
                bottomSheet.setBackground(new ColorDrawable(android.graphics.Color.TRANSPARENT));

                //width size 조절.
                LinearLayout.MarginLayoutParams params = (LinearLayout.MarginLayoutParams) bottomSheetLayout.getLayoutParams();
                params.rightMargin = DefaultUtil.dpToPx(15, getContext());
                params.leftMargin = DefaultUtil.dpToPx(15, getContext());
                bottomSheetLayout.setLayoutParams(params);


                BottomSheetBehavior.from(bottomSheet).setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
                    @Override
                    public void onStateChanged(@NonNull View bottomSheet, int newState) {
                        if (newState == BottomSheetBehavior.STATE_DRAGGING) {
                            BottomSheetBehavior.from(bottomSheet).setState(BottomSheetBehavior.STATE_EXPANDED);
                        }
                    }

                    @Override
                    public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                    }
                });
            }
        });

        return dialog;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_yesno_bottom, container, false);
        cancelBtn = view.findViewById(R.id.cancelBtn);
        confirmBtn = view.findViewById(R.id.confirmBtn);
        titleTV= view.findViewById(R.id.titleTV);
        contentTV = view.findViewById(R.id.contentTV);
        bottomSheetLayout = view.findViewById(R.id.bottomSheetLayout);

        switch (getTag()) {
            case "delete":
                contentTV.setText(R.string.delete_message);
                break;

            default:
                break;
        }

        confirmBtn.setOnClickListener(v -> {
            isConfirm = true;
            dismiss();
        });

        cancelBtn.setOnClickListener(v -> {
            isConfirm = false;
            dismiss();
        });

        return view;
    }

    @Override
    public void show(FragmentManager manager, String tag) {
        FragmentTransaction ft = manager.beginTransaction();
        ft.add(this, tag);
        ft.commitAllowingStateLoss();
    }
}
