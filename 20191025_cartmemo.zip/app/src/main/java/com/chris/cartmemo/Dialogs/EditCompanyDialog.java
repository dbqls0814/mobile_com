package com.chris.cartmemo.Dialogs;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.chris.cartmemo.DB.CompanyDB;
import com.chris.cartmemo.DefaultUtil;
import com.chris.cartmemo.MainActivity;
import com.chris.cartmemo.MainController;
import com.chris.cartmemo.R;

public class EditCompanyDialog extends Dialog {
    private Button saveBtn;
    private Button deleteBtn;
    private Button cancelBtn;
    private EditText nameET;
    private TextView nameCheckTV;
    private TextView titleTV;
    public boolean addCompany =false;

    public EditCompanyDialog(Context context) {
        super(context);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.dialog_add_company);

        titleTV = findViewById(R.id.titleTV);
        titleTV.setText("매장정보 수정");
        saveBtn = findViewById(R.id.saveBtn);
        cancelBtn = findViewById(R.id.cancelBtn);
        deleteBtn = findViewById(R.id.deleteBtn);
        deleteBtn.setVisibility(View.VISIBLE);
        nameET = findViewById(R.id.nameET);
        nameET.setText(MainController.getInstance().SelectedCompany.getName());
        nameCheckTV = findViewById(R.id.nameCheckTV);

        //다이얼로그 크기 조절.
        DefaultUtil.getDialogSize(getContext(), this);

        nameET.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!nameET.getText().toString().trim().isEmpty()) {
                    nameCheckTV.setVisibility(View.GONE);
                } else {
                    nameCheckTV.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void afterTextChanged(Editable arg0) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
        });

        deleteBtn.setOnClickListener(v->{

            DialogDeletePayConfirm();

        });

        setCancelable(false);
        cancelBtn.setOnClickListener(v -> dismiss());
        saveBtn.setOnClickListener(v -> UpdateInfo());
    }


    private void UpdateInfo() {
        //name blank check
        if (nameET.getText().toString().trim().isEmpty()) {
            nameCheckTV.setVisibility(View.VISIBLE);
            nameET.requestFocus();
            return;
        }

        MainController.getInstance().dbHelper.updateCompany(MainController.getInstance().SelectedCompany.getId(), nameET.getText().toString());
        addCompany =true;

        dismiss();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        dismiss();
    }

    private YesNoBottomDialog editConfirmDialog;

    private void DialogDeletePayConfirm() {
        if (editConfirmDialog != null && editConfirmDialog.isVisible()) {
            return;
        }
        editConfirmDialog = new YesNoBottomDialog();

        editConfirmDialog.show(MainActivity.mainActivity.getSupportFragmentManager(), "delete");
        MainActivity.mainActivity.getSupportFragmentManager().executePendingTransactions();
        editConfirmDialog.getDialog().setOnDismissListener(dialog -> {
            if (editConfirmDialog.isConfirm) {

                //삭제
                if(MainController.getInstance().dbHelper != null)
                {
                    MainController.getInstance().dbHelper.deleteColumn(CompanyDB._TABLENAME0, MainController.getInstance().SelectedCompany.getId());
                    MainController.getInstance().IdashBoardFragment.Update();
                    dismiss();
                }
            }
            editConfirmDialog.dismiss();
        });
    }
}
